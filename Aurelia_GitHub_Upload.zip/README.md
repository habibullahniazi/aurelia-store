# Aurelia Store

Static shopping website demo. Upload index.html to the root of your GitHub repository and enable GitHub Pages from the main branch. Checkout is demo-only; no real orders or payments are processed.
